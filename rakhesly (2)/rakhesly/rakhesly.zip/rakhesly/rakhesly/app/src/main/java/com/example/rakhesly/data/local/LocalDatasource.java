package com.example.rakhesly.data.local;

public class LocalDatasource {
}
