package com.example.rakhesly.ui.main;

public class MainViewModel {
}
